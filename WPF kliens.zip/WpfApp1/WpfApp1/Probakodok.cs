﻿
/*                  GETALL v1
using (HttpClient client = new HttpClient())
{
    var response = await client.GetAsync(url);
    response.EnsureSuccessStatusCode();
    if (response.IsSuccessStatusCode)
    {
        String res = await response.Content.ReadAsStringAsync();
        //JObject s = JObject.Parse(res);
        Trace.WriteLine(res);
        if (res is not null)
        {
            products = JsonConvert.DeserializeObject<List<Product>>(res);
        }

        foreach (Product termek in products)
        {
            allProductsListBox.Items.Add(termek.productId + " " + termek.productName + " " + termek.unitPrice + "$");
        }
    }
    else
    {
        Trace.WriteLine("FAIL");
    }
}
*/


/*                  GETBYID v1
using (HttpClient client = new HttpClient())
{
    var response = await client.GetAsync(uri);
    response.EnsureSuccessStatusCode();
    String valasz;
    if (response.IsSuccessStatusCode)
    {
        valasz = await response.Content.ReadAsStringAsync();
        Trace.WriteLine(valasz);
        prodid.Content = valasz;
        prodnam.Content = valasz;
        prodpric.Content = valasz;
        prodcatid.Content = valasz;
    }
    else
    {
        valasz = $"Server error code {response.StatusCode} ";
        Trace.WriteLine(valasz);
    }
}*/